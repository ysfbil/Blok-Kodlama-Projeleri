framework.internalImgPaths = {
  "imgFiles": [
    {
      "path": "resources/img/000.png"
    },
    {
      "path": "resources/img/001.png"
    },
    {
      "path": "resources/img/002.png"
    },
    {
      "path": "resources/img/003.png"
    },
    {
      "path": "resources/img/004.png"
    },
    {
      "path": "resources/img/005.png"
    },
    {
      "path": "resources/img/006.png"
    },
    {
      "path": "resources/img/007.png"
    },
    {
      "path": "resources/img/008.png"
    },
    {
      "path": "resources/img/009.png"
    },
    {
      "path": "resources/img/010.png"
    },
    {
      "path": "resources/img/011.png"
    },
    {
      "path": "resources/img/012.png"
    },
    {
      "path": "resources/img/013.png"
    },
    {
      "path": "resources/img/014.png"
    },
    {
      "path": "resources/img/015.png"
    },
    {
      "path": "resources/img/016.png"
    },
    {
      "path": "resources/img/017.png"
    },
    {
      "path": "resources/img/018.png"
    },
    {
      "path": "resources/img/019.png"
    },
    {
      "path": "resources/img/020.png"
    },
    {
      "path": "resources/img/021.png"
    },
    {
      "path": "resources/img/022.png"
    },
    {
      "path": "resources/img/023.png"
    },
    {
      "path": "resources/img/024.png"
    },
    {
      "path": "resources/img/025.png"
    },
    {
      "path": "resources/img/026.png"
    },
    {
      "path": "resources/img/027.png"
    },
    {
      "path": "resources/img/028.png"
    },
    {
      "path": "resources/img/029.png"
    },
    {
      "path": "resources/img/030.png"
    },
    {
      "path": "resources/img/031.png"
    },
    {
      "path": "resources/img/032.png"
    },
    {
      "path": "resources/img/dogru.png"
    },
    {
      "path": "resources/img/yanlis.png"
    }
  ]
}