framework.internalImgPaths = {
  "imgFiles": [
    {
      "path": "resources/img/000.jpg"
    },
    {
      "path": "resources/img/001.jpg"
    },
    {
      "path": "resources/img/002.jpg"
    },
    {
      "path": "resources/img/003.jpg"
    },
    {
      "path": "resources/img/004.jpg"
    },
    {
      "path": "resources/img/005.jpg"
    },
    {
      "path": "resources/img/006.jpg"
    },
    {
      "path": "resources/img/007.jpg"
    },
    {
      "path": "resources/img/008.jpg"
    },
    {
      "path": "resources/img/009.jpg"
    },
    {
      "path": "resources/img/010.jpg"
    },
    {
      "path": "resources/img/011.jpg"
    },
    {
      "path": "resources/img/012.jpg"
    },
    {
      "path": "resources/img/013.jpg"
    },
    {
      "path": "resources/img/014.jpg"
    },
    {
      "path": "resources/img/015.jpg"
    },
    {
      "path": "resources/img/016.jpg"
    },
    {
      "path": "resources/img/017.jpg"
    },
    {
      "path": "resources/img/018.jpg"
    },
    {
      "path": "resources/img/019.jpg"
    },
    {
      "path": "resources/img/020.jpg"
    },
    {
      "path": "resources/img/021.jpg"
    },
    {
      "path": "resources/img/022.jpg"
    },
    {
      "path": "resources/img/023.jpg"
    },
    {
      "path": "resources/img/024.jpg"
    },
    {
      "path": "resources/img/025.jpg"
    },
    {
      "path": "resources/img/026.jpg"
    },
    {
      "path": "resources/img/027.jpg"
    },
    {
      "path": "resources/img/028.jpg"
    },
    {
      "path": "resources/img/029.jpg"
    },
    {
      "path": "resources/img/030.jpg"
    },
    {
      "path": "resources/img/031.jpg"
    },
    {
      "path": "resources/img/032.jpg"
    },
    {
      "path": "resources/img/033.jpg"
    },
    {
      "path": "resources/img/034.jpg"
    },
    {
      "path": "resources/img/035.jpg"
    },
    {
      "path": "resources/img/036.jpg"
    },
    {
      "path": "resources/img/037.jpg"
    },
    {
      "path": "resources/img/038.jpg"
    },
    {
      "path": "resources/img/039.jpg"
    },
    {
      "path": "resources/img/040.jpg"
    },
    {
      "path": "resources/img/dogru.jpg"
    },
    {
      "path": "resources/img/yanlis.png"
    }
  ]
}