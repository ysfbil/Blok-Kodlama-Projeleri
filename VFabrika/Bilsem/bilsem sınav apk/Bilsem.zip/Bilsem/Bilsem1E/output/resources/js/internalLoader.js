framework.internalWidgetSource  = {
  "jsFiles": [
    {
      "path": "js/vfabrika-core.js"
    },
    {
      "path": "js/vfabrika-plugins.js"
    },
    {
      "path": "js/vfabrika-bundles.js"
    },
    {
      "path": "js/vfabrika-player-data.js"
    },
    {
      "path": "js/highlights.js"
    },
    {
      "path": "js/Bilsem1E.js"
    }
  ],
  "cssFiles": [
    {
      "path": "css/VFabrika.css"
    },
    {
      "path": "css/GlobalStyles_Bilsem1E.css"
    }
  ]
};

